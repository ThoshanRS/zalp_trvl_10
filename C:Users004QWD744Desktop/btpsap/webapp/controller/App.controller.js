sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.ibm.zpurchase10.btpsap.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  