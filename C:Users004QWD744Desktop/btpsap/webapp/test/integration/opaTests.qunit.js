/* global QUnit */

sap.ui.require(["com/ibm/zpurchase10/btpsap/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
