sap.ui.define([
	"comibmzpurchase10/btpsap/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
